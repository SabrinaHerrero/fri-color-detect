#ifndef _ROS_opencv_apps_LineArrayStamped_h
#define _ROS_opencv_apps_LineArrayStamped_h

#include <stdint.h>
#include <string.h>
#include <stdlib.h>
#include "ros/msg.h"
#include "std_msgs/Header.h"
#include "opencv_apps/Line.h"

namespace opencv_apps
{

  class LineArrayStamped : public ros::Msg
  {
    public:
      std_msgs::Header header;
      uint8_t lines_length;
      opencv_apps::Line st_lines;
      opencv_apps::Line * lines;

    LineArrayStamped():
      header(),
      lines_length(0), lines(NULL)
    {
    }

    virtual int serialize(unsigned char *outbuffer) const
    {
      int offset = 0;
      offset += this->header.serialize(outbuffer + offset);
      *(outbuffer + offset++) = lines_length;
      *(outbuffer + offset++) = 0;
      *(outbuffer + offset++) = 0;
      *(outbuffer + offset++) = 0;
      for( uint8_t i = 0; i < lines_length; i++){
      offset += this->lines[i].serialize(outbuffer + offset);
      }
      return offset;
    }

    virtual int deserialize(unsigned char *inbuffer)
    {
      int offset = 0;
      offset += this->header.deserialize(inbuffer + offset);
      uint8_t lines_lengthT = *(inbuffer + offset++);
      if(lines_lengthT > lines_length)
        this->lines = (opencv_apps::Line*)realloc(this->lines, lines_lengthT * sizeof(opencv_apps::Line));
      offset += 3;
      lines_length = lines_lengthT;
      for( uint8_t i = 0; i < lines_length; i++){
      offset += this->st_lines.deserialize(inbuffer + offset);
        memcpy( &(this->lines[i]), &(this->st_lines), sizeof(opencv_apps::Line));
      }
     return offset;
    }

    const char * getType(){ return "opencv_apps/LineArrayStamped"; };
    const char * getMD5(){ return "8ad5d104256b4f6774479453d1118f74"; };

  };

}
#endif